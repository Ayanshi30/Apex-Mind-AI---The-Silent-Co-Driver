import { NextResponse } from 'next/server'

export const runtime = 'nodejs'

const AUDIO_TYPES = new Set(['audio/mpeg', 'audio/wav', 'audio/x-wav', 'audio/mp4', 'audio/webm', 'audio/ogg', 'audio/aac'])

function numberFrom(value: unknown, fallback: number) {
  const parsed = Number(value)
  return Number.isFinite(parsed) ? parsed : fallback
}

export async function POST(request: Request) {
  try {
    const form = await request.formData()
    const audio = form.get('audio')
    const telemetry = form.get('telemetry')
    const metadata = form.get('metadata')

    if (!(audio instanceof File) && !(telemetry instanceof File) && typeof telemetry !== 'string') {
      return NextResponse.json({ error: 'Add an audio file or telemetry JSON payload.' }, { status: 400 })
    }

    if (audio instanceof File && !AUDIO_TYPES.has(audio.type) && !audio.name.match(/\.(mp3|wav|m4a|webm|ogg|aac)$/i)) {
      return NextResponse.json({ error: 'Unsupported audio format. Use MP3, WAV, M4A, WEBM, OGG, or AAC.' }, { status: 415 })
    }

    let telemetryPayload: Record<string, unknown> = {}
    const telemetryText = typeof telemetry === 'string' ? telemetry : telemetry instanceof File ? await telemetry.text() : ''
    if (telemetryText.trim()) {
      try {
        const parsed = JSON.parse(telemetryText)
        telemetryPayload = parsed && typeof parsed === 'object' ? parsed : {}
      } catch {
        return NextResponse.json({ error: 'Telemetry must be valid JSON.' }, { status: 400 })
      }
    }

    const source = metadata instanceof File ? metadata.name : typeof metadata === 'string' ? metadata : audio instanceof File ? audio.name : 'telemetry payload'
    const stress = Math.round(numberFrom(telemetryPayload.stress, 58 + (audio ? 9 : 0)))
    const confidence = Math.round(numberFrom(telemetryPayload.confidence, Math.max(42, 94 - stress / 2)))
    const frustration = Math.round(numberFrom(telemetryPayload.frustration, Math.max(12, stress - 18)))
    const speed = Math.round(numberFrom(telemetryPayload.speed, 286 + (stress % 17)))
    const lapTime = Number(numberFrom(telemetryPayload.lapTime, 84.2 + stress / 100)).toFixed(3)

    return NextResponse.json({
      ok: true,
      source,
      receivedAt: new Date().toISOString(),
      audio: audio instanceof File ? { name: audio.name, type: audio.type || 'audio/*', size: audio.size, durationSeconds: null } : null,
      analysis: {
        transcript: audio instanceof File ? 'Audio received. Connect your speech-to-text model here to replace this transcript.' : 'Telemetry payload received and normalized.',
        stress,
        confidence,
        frustration,
        speed,
        lapTime,
        signal: stress > 70 ? 'elevated' : 'stable',
        recommendations: [stress > 70 ? 'Review rear grip and brake temperature immediately.' : 'Maintain smooth inputs through the next sector.', 'Keep the audio and telemetry timestamps synchronized for model correlation.'],
      },
      telemetry: telemetryPayload,
    })
  } catch {
    return NextResponse.json({ error: 'Unable to process the upload.' }, { status: 500 })
  }
}
